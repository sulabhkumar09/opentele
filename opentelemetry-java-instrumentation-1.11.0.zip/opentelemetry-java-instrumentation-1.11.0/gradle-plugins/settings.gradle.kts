pluginManagement {
  plugins {
    id("com.gradle.plugin-publish") version "0.15.0"
    id("io.github.gradle-nexus.publish-plugin") version "1.1.0"
  }
}
