### Scope of this repository

Both javaagent and library-based approaches to the following:

* Instrumentation for specific Java libraries and frameworks
  * Emitting spans and metrics (and in the future logs)
* System metrics
* MDC logging integrations
  * Encoding traceId/spanId into logs
* Spring Boot starters
