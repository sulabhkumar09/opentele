/** Provides utility classes to provide support for instrumenting annotated methods. */
@UnstableApi
package io.opentelemetry.instrumentation.api.annotation.support;

import io.opentelemetry.instrumentation.api.annotations.UnstableApi;
