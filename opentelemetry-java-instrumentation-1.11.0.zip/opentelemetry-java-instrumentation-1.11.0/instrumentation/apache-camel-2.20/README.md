# Settings for the Apache Camel instrumentation

| System property | Type | Default | Description |
|---|---|---|---|
| `otel.instrumentation.apache-camel.experimental-span-attributes` | Boolean | `false` | Enable the capture of experimental span attributes.  |
